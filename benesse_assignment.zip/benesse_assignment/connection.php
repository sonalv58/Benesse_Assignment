<?php      
  $hostname='localhost';
  $dbname='assignment';
  $username='root';
  $password='password';
      $conn= mysqli_connect($hostname,$dbname,$username,$password);

        if(!$conn){
            echo "Connection Error";

        }
   
?>  