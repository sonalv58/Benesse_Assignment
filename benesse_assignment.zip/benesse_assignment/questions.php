<form method="post">
    <?php

    include('connection.php');  
    $query= "select * from questions";
    $result= mysqli_query($conn,$query);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  

    foreach($row as $value)
    {
        ?>
        <div >
            <input type="hidden" name="ques"/><?php echo $value['Question_Text'];?>
        </div>
        <div >
            <select name="ques" > 
        
                <input type="radio" name="<?php echo $value['Option_A'];?>" value="<?php echo $value['Option_A'];?>"><?php echo $value['Option_A'];?></label>
                <input type="radio" name="<?php echo $value['Option_B'];?>" value="<?php echo $value['Option_B'];?>"><?php echo $value['Option_B'];?></label>
         
                <input type="radio" name="<?php echo $value['Option_C'];?>" value="<?php echo $value['Option_C'];?>"><?php echo $value['Option_C'];?></label>
         
                <input type="radio" name="<?php echo $value['Option_D'];?>" value="<?php echo $value['Option_D'];?>"><?php echo $value['Option_D'];?></label>
          </select>
        </div>
        <?php
    }

    ?>

 
    <button type="submit" name="submit">Submit</button>
   <?php
      if(isset($_POST['submit'])){
        foreach ($_POST['ques'] as $select)
        {
        echo "You have selected :" .$select; 
        }
    }
    ?>
</form>