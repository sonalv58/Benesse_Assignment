<?php
include('connection.php');  

if(isset($_POST['submit'])){

$emailId= $_POST['emailId'];
$password= $_POST['password'];

	$query= "select * from user where email_id = '$emailId' and password = '$password'";  

	$result= mysqli_query($conn,$query);
    $countRows = mysqli_num_rows($result);  
    $redirect_url="http://localhost/benesse_assignment/questions.php";
    
    if($countRows == 1){  
      header("Location: $redirect_url"); 
        }  
    else{  
            echo "<h1>Invalid email id  or password.</h1>";  
        }     

}





?>